Halo...👋

Saya mau menjelaskan cara mengisi config.json.

📚 Ini Format Nya:

{
"PREFIX": "",
"TOKEN": "",
"ID_CHANNEL": "",
"TAG": "",
"ID_ROLE": "",
"ID_ROLE_REMOVE": "",
"STATUS": "",
"TYPE_STATUS": ""
}

📗 Guide :

1. Isi Prefix Bot Yang Kamu Mau. | (WAJIB)
2. Isi Token Sesuai Token Bot Kamu. | (WAJIB)
3. Isi Id Channel Kamu Untuk Register Secara Private, Jadi Command Register Ngga Bisa Digunakan Kecuali Channel Id Private Kamu Yang Untuk Register. | (WAJIB)
4. Isi Tag kamu, Contoh: [MEMBER] | (Jika Diperlukan Saja)
5. Isi Id Role kamu, Ini Role Yang Ketika Kamu Register Role Akan Ke Add. | (WAJIB)
6. Isi Id Role Remove Kamu, Ini Role Yang Ketika Kamu Register Role Ya Akan Kehapus. | (Jika Diperlukan Saja)
7. Isi Status Bot Kamu. | (WAJIB)
8. Isi Type Status Kamu Seperti ( PLAYING, WACTHING, LISTENING, STREAMING ). | (WAJIB)

Kalau Mau Lebih Jelas Lihat Videonya Aja Oke...

Command Ada 2 Ya Guys, Yaitu: ping & register.

Nah segitu aja penjelasan saya dan mohon maaf kalo saya menjelaskannya kurang jelas.

Thanks You🙏

🔗 Link:

Youtube: https://www.youtube.com/channel/UCz30CHhoifrK6amZ5eKAIEQ/
Developer Bot: https://discord.com/developers/applications
Glitch: https://glitch.com/
